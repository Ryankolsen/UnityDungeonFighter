using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Chest : Collectable
{
    public Sprite emptryChest;
    public int goldAmnt = 5;

    protected override void onCollect()
    {
        if (!collected)
        {
            collected = true;
            GetComponent<SpriteRenderer>().sprite = emptryChest;
            GameManager.instance.ShowText("+ " + goldAmnt + "Gold!", 25, Color.yellow, transform.position, Vector3.up * 50, 1.5f) ; //tranform.position = position of the chest
            GameManager.instance.gold += goldAmnt;

        }
    }




}
