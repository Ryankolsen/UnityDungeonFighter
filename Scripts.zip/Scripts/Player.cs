using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : Mover
{

    
    private SpriteRenderer spriteRenderer;
    private bool isAlive = true;

    protected override void Start()
    {
        base.Start();
        spriteRenderer = GetComponent<SpriteRenderer>();

        
    }

    protected override void ReceiveDamage(Damage dmg)
    {
        if (!isAlive)
            return;
        base.ReceiveDamage(dmg);
        GameManager.instance.OnHitPointChange();
    }

    protected override void Death()
    {
        isAlive = false;
        GameManager.instance.deathMenuAnim.SetTrigger("Show");
    }

    private void FixedUpdate()
    {

        float x = Input.GetAxisRaw("Horizontal");   //returns -1,1 or 0 if going left right or neither
        float y = Input.GetAxisRaw("Vertical");    //same as above for vertical y axis
        if(isAlive)
            UpdateMotor(new Vector3(x, y, 0));  //update wth player movement
    }

    public void SwapSprite(int skinId)
    {
        spriteRenderer.sprite = GameManager.instance.playerSprites[skinId];
        //GetComponent<SpriteRenderer>().sprite = GameManager.instance.playerSprites[skinId];
    }

    public void OnLevelUp()
    {
        maxhitpoint++; //get one hp each level
        hitpoint = maxhitpoint; //on level fill hp
        GameManager.instance.ShowText("LEVEL Up", 25, Color.white, transform.position, Vector3.up * 30, 1.0f);
        Debug.Log("OnLevelUp Function from player");

    }

    //Set correct level at start of the game
    public void SetLevel(int level)
    {
        for (int i = 0; i < level; i++)
            OnLevelUp();

    }

    public void Heal(int healingAmount)
    {
        if (hitpoint == maxhitpoint)
            return;

        hitpoint += healingAmount;
        if (hitpoint > maxhitpoint)
            hitpoint = maxhitpoint; 
        GameManager.instance.ShowText("+" + healingAmount.ToString() + " HP", 25, Color.green, transform.position, Vector3.up * 30, 1.0f);
        GameManager.instance.OnHitPointChange();


    }

    public void Respawn()
    {
        Heal(maxhitpoint);
        isAlive = true;
        lastImmune = Time.time;
        pushDirectoin = Vector3.zero;
        GameManager.instance.Respawn();
    } 
}
