using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CharacterMenu : MonoBehaviour
{
    //Menu values
    public Text levelText, hitpointText, goldText, upgradeCostText, xpText;

    private int currentCharSelection = 0;
    public Image charSelectionSprite;
    public Image weaponSprite;
    public RectTransform xpBar;

    //Character Selection
    public void OnArrowCollide(bool right)
    {
        if (right)
        {
            currentCharSelection++;
            //if we went too far away
            if (currentCharSelection == GameManager.instance.playerSprites.Count)
                currentCharSelection = 0;

            OnSelectionChanged();

        }
        else
        {
            //if we went too far away
            if (currentCharSelection < 0)
                currentCharSelection = GameManager.instance.playerSprites.Count - 1;

            OnSelectionChanged();
        }


    }

    public void OnArrowCollide2(bool left)
    {
        if (left)
        {
            currentCharSelection--;
            //if we went too far away
            if (currentCharSelection == -1)
                currentCharSelection = GameManager.instance.playerSprites.Count;

            OnSelectionChanged();

        }
        else
        {
            //if we went too far away
            if (currentCharSelection < 0)
                currentCharSelection = GameManager.instance.playerSprites.Count - 1;

            OnSelectionChanged();
        }


    }

    private void OnSelectionChanged()
    {
        charSelectionSprite.sprite = GameManager.instance.playerSprites[currentCharSelection];
        GameManager.instance.player.SwapSprite(currentCharSelection);
    }

    //Weapon upgrade
    public void onUpgradeClick()
    {
        if (GameManager.instance.TryUpgradeWeapon())
            UpdateMenue();
    }

    // Update character info
    public void UpdateMenue()
    {
        //Weapon
        weaponSprite.sprite = GameManager.instance.weaponSprites[GameManager.instance.weapon.weaponLevel];
        if (GameManager.instance.weapon.weaponLevel == GameManager.instance.weaponPrices.Count)
            upgradeCostText.text = "MAX";
        else
            upgradeCostText.text = (GameManager.instance.weaponPrices[GameManager.instance.weapon.weaponLevel]).ToString();

        //meta
        levelText.text = GameManager.instance.GetCurrentLevel().ToString();
        hitpointText.text = GameManager.instance.player.hitpoint.ToString();
        goldText.text = GameManager.instance.gold.ToString();


        //xp Bar
        int currlevel = GameManager.instance.GetCurrentLevel();
        if (currlevel == GameManager.instance.xpTable.Count)
        {
            xpText.text = GameManager.instance.experience.ToString () + " total xp"; //display total xp if max level
            xpBar.localScale = Vector3.one;
        }
        else
        {
            int prevlevelxp = GameManager.instance.GetXpToLevel(currlevel - 1);
            int currlevelxp = GameManager.instance.GetXpToLevel(currlevel);

            int diff = currlevelxp - prevlevelxp;
            int currxpintolevel = GameManager.instance.experience - prevlevelxp;
          


            float completionratio = (float)currxpintolevel / (float)diff;
           


            xpBar.localScale = new Vector3(completionratio,  1, 1);
            xpText.text = currxpintolevel.ToString() + " / " + diff;
        }

    }


}
