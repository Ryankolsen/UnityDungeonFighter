using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : Mover
{
    //Experience
    public int xpValue = 1;

    public float triggerLength = 1;     //engagement distance to player
    public float chaselength = 5;       //will chase for 5 meters, then return
    private bool chasing;
    private bool collidingWithPlayer;   //is enemy colliding with player? (if so, do not keep moving)
    private Transform playerTransform;  
    private Vector3 startingPosition;

    //Hitbox (enemy weapon)
    public ContactFilter2D filter;
    private BoxCollider2D hitbox;
    private Collider2D[] hits = new Collider2D[10];

    protected override void Start()
    {
        base.Start();
        playerTransform = GameManager.instance.player.transform;    //player position
        startingPosition = transform.position;  //enemy starting position
        hitbox = transform.GetChild(0).GetComponent<BoxCollider2D>(); //identify box collider "Hitbox"

    }

    private void FixedUpdate()
    {
        //movement of enemy
        //Is the player in range?
        if(Vector3.Distance(playerTransform.position, startingPosition) < chaselength)
        {
            if (Vector3.Distance(playerTransform.position, startingPosition) < triggerLength)       //if value is retuned, they chasing = true
            {
                chasing = true;
            }
            if (chasing)
            {
                if (!collidingWithPlayer)
                {
                    UpdateMotor((playerTransform.position - transform.position).normalized);    //go in direction of player if not colliding
                }
            }
            else
            {
                UpdateMotor(startingPosition - transform.position);     //if colliding with player, stop moving
            }
          
        }
        else
        {
            UpdateMotor(startingPosition - transform.position);     //go back to starting point, player ran away
            chasing = false;
        }

        //Check for overlap
        collidingWithPlayer = false;
        boxCollider.OverlapCollider(filter, hits);      //finds anythign in contact with box collider and places in hits array
        for (int i = 0; i < hits.Length; i++)
        {
            if (hits[i] == null)
                continue;

            if(hits[i].tag =="Fighter" && hits[i].name == "Player")
            {
                collidingWithPlayer = true;
            }

            //Clear array
            hits[i] = null;

        }

    }

    protected override void Death()
    {
        Destroy(gameObject);        //removes enemy game object
        GameManager.instance.GrantXp(xpValue);
        GameManager.instance.ShowText("+" + xpValue + " xp", 30, Color.blue, transform.position, Vector3.up * 40, 1.0f);
    }
}
