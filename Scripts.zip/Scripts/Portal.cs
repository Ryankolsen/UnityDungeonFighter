using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Portal : Collidable
{
    public string[] sceneNames;

    protected override void onCollide(Collider2D coll)
    {
        if (coll.name == "Player")
        {
            //Teleport Player to random dungeon
            string sceneName = sceneNames[Random.Range(0, sceneNames.Length)];
            //save game
            GameManager.instance.SaveState();
            //load the scene:
            SceneManager.LoadScene(sceneName);
        }
    }


}
