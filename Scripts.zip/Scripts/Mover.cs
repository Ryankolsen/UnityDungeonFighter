using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class Mover : Fighter //must use inheritance to access abstract class
{
    private Vector3 originalSize;

    protected BoxCollider2D boxCollider;
    protected Vector3 moveDelta;  //player's current position
    protected RaycastHit2D hit;   //will allow player to collide with objects/environment
    public float ySpeed = 0.75f;
    public float xSpeed = 1.0f;

    protected virtual void Start()
    {
        originalSize = transform.localScale;
        boxCollider = GetComponent<BoxCollider2D>();
    }
 

    protected virtual void UpdateMotor(Vector3 input)
    {
        //Reset MoveDelta
        moveDelta = new Vector3(input.x * xSpeed, input.y * ySpeed, 0);

        //Swap sprite direction for r and l
        if (moveDelta.x > 0)
            transform.localScale = originalSize;
        else if (moveDelta.x < 0)
            transform.localScale = new Vector3(originalSize.x * -1, originalSize.y, originalSize.z);

        //Add push vector if any
        moveDelta += pushDirectoin;

        //Reduce push force each frame based off recovery speed
        pushDirectoin = Vector3.Lerp(pushDirectoin, Vector3.zero, pushRecoverySpeed);


        //cast a box before player moves, if box returns null, player can move
        hit = Physics2D.BoxCast(transform.position, boxCollider.size, 0, new Vector2(0, moveDelta.y), Mathf.Abs(moveDelta.y * Time.deltaTime), LayerMask.GetMask("Player", "Blocking"));
        if (hit.collider == null)
        {
            //Move Player
            transform.Translate(0, moveDelta.y * Time.deltaTime, 0); //equates movement speed accounting for user device speed (makes game fair)

        }
        hit = Physics2D.BoxCast(transform.position, boxCollider.size, 0, new Vector2(moveDelta.x, 0), Mathf.Abs(moveDelta.x * Time.deltaTime), LayerMask.GetMask("Player", "Blocking"));
        if (hit.collider == null)
        {
            //Move Player
            transform.Translate(moveDelta.x * Time.deltaTime, 0, 0); //equates movement speed accounting for user device speed (makes game fair)
                                                                     //edit -->project settings-->physics 2D --> turn off "queries start in collider"

        }




    }
}
