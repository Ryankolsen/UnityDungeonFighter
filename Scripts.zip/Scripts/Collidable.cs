using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Collidable : MonoBehaviour
{
    public ContactFilter2D filter;
    private BoxCollider2D boxCollider;
    private Collider2D[] hits = new Collider2D[10];
     
    protected virtual void Start()
    {
        boxCollider = GetComponent<BoxCollider2D>();    //will require boxcollider2D
    }

    protected virtual void Update()
    {
        //Collision work
        boxCollider.OverlapCollider(filter, hits);      //finds anythign in contact with box collider and places in hits array
        for (int i = 0; i < hits.Length; i++)
        {
            if(hits[i] == null)
                continue;

            onCollide(hits[i]);

            //Clear array
            hits[i] = null;
            
        }
    }

    protected virtual void onCollide(Collider2D coll)
    {
        //Debug.Log("OnCollide was not implementerd in " + this.name);
    }

}
